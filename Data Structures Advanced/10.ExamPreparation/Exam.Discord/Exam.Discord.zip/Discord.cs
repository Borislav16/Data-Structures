﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exam.Discord
{
    public class Discord : IDiscord
    {
        private Dictionary<string, Message> discord;
        private Dictionary<string, List<Message>> channelMessages;

        public Discord()
        {
            this.discord = new Dictionary<string, Message>();
            this.channelMessages = new Dictionary<string, List<Message>>();
        }

        public int Count
            => this.discord.Count;

        public bool Contains(Message message)
            => this.discord.ContainsKey(message.Id);

        public void SendMessage(Message message)
        {
            this.discord.Add(message.Id, message);

            if (!channelMessages.ContainsKey(message.Channel))
            {
                this.channelMessages.Add(message.Channel, new List<Message>());
            }

            this.channelMessages[message.Channel].Add(message);
        }

        public void DeleteMessage(string messageId)
        {
            if (!this.discord.ContainsKey(messageId))
            {
                throw new ArgumentException();
            }

            var messageToDeleteInChannel = this.channelMessages[this.discord[messageId].Channel]
                .FirstOrDefault(m => m.Id == messageId);

            if (messageToDeleteInChannel == null)
            {
                throw new ArgumentException();
            }
            else
            {
                this.channelMessages[this.discord[messageId].Channel].Remove(messageToDeleteInChannel);
            }

            this.discord.Remove(messageId);
        }

        public Message GetMessage(string messageId)
        {
            if (!this.discord.ContainsKey(messageId))
            {
                throw new ArgumentException();
            }

            return this.discord[messageId];
        }

        public IEnumerable<Message> GetAllMessagesOrderedByCountOfReactionsThenByTimestampThenByLengthOfContent()
            => this.discord.Values
                .OrderByDescending(m => m.Reactions.Count)
                .ThenBy(m => m.Timestamp)
                .ThenBy(m => m.Content.Length);

        public IEnumerable<Message> GetChannelMessages(string channel)
        {
            if (!this.channelMessages.ContainsKey(channel))
            {
                throw new ArgumentException();
            }

            return this.channelMessages[channel];
        }

        public IEnumerable<Message> GetMessageInTimeRange(int lowerBound, int upperBound)
            => this.discord.Values
                .Where(m => m.Timestamp >= lowerBound && m.Timestamp <= upperBound)
                .OrderByDescending(m => m.Channel);

        public IEnumerable<Message> GetMessagesByReactions(List<string> reactions)
            => this.discord.Values
                .Where(m => m.Reactions.Intersect(reactions).Any())
                .OrderByDescending(m => m.Reactions.Count)
                .ThenByDescending(m => m.Timestamp);

        public IEnumerable<Message> GetTop3MostReactedMessages()
            => this.discord.Values
                .OrderByDescending(m => m.Reactions.Count)
                .Take(3);

        public void ReactToMessage(string messageId, string reaction)
        {
            if (!this.discord.ContainsKey(messageId))
            {
                throw new ArgumentException();
            }

            this.discord[messageId].Reactions.Add(reaction);
        }
    }
}